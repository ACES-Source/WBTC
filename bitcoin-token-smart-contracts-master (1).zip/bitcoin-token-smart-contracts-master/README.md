This repository has the contracts that implement the wrapped tokens.

# Ethereum network
[ethereumV2/README.md](ethereumV2/README.md)

# Tron network
[tron/README.md](tron/README.md)

# Original Ethereum network
[ethereum/README.md](ethereum/README.md)